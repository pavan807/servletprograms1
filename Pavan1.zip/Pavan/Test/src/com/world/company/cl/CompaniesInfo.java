package com.world.company.cl;
import java.util.List;
import java.util.Map;

import com.world.company.Company;

public class CompaniesInfo
{
	/*List<Map<Integer, Company>> companiesList;

	public List<Map<Integer, Company>> getCompaniesList() {
		return companiesList;
	}

	public void setCompaniesList(List<Map<Integer, Company>> companiesList) {
		this.companiesList = companiesList;
	}

	@Override
	public String toString() {
		return "CompaniesInfo [companiesList=" + companiesList + "]";
	}*/
	
	
	Map<Integer, Company> companiesList;

	public Map<Integer, Company> getCompaniesList() {
		return companiesList;
	}

	public void setCompaniesList(Map<Integer, Company> companiesList) {
		this.companiesList = companiesList;
	}

	@Override
	public String toString() {
		return "CompaniesInfo [companiesList=" + companiesList + "]";
	}
	
	
	
}
