package com.world.company;

public class IBM extends Company 
{
	public IBM(int cId, String name, String mainBranchLocation, int noOfEmloyees, long noOfProjects) {
		super(cId, name, mainBranchLocation, noOfEmloyees, noOfProjects);
	}

	@Override
	public String toString() {
		return "IBM [cId=" + cId + ", name=" + name + ", mainBranchLocation=" + mainBranchLocation + ", noOfEmloyees="
				+ noOfEmloyees + ", noOfProjects=" + noOfProjects + "]";
	}
	
}
