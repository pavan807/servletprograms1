package com.world.company;

public class Prolifics extends Company 
{
	public Prolifics(int cId, String name, String mainBranchLocation, int noOfEmloyees, long noOfProjects) {
		super(cId, name, mainBranchLocation, noOfEmloyees, noOfProjects);
	}
}
