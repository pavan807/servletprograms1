package com.world.company;

public class CTS extends Company
{
	public CTS(int cId, String name, String mainBranchLocation, int noOfEmloyees, long noOfProjects) {
		super(cId, name, mainBranchLocation, noOfEmloyees, noOfProjects);
	}

	@Override
	public String toString() {
		return "CTS [cId=" + cId + ", name=" + name + ", mainBranchLocation=" + mainBranchLocation + ", noOfEmloyees="
				+ noOfEmloyees + ", noOfProjects=" + noOfProjects + "]";
	}
	
}
