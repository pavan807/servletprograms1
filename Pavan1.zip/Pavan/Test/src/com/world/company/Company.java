package com.world.company;
public abstract class Company
{
	int cId;
	String name;
	String mainBranchLocation;
	int noOfEmloyees;
	long noOfProjects;
	
	public Company(int cId, String name, String mainBranchLocation, int noOfEmloyees, long noOfProjects) {
		this.cId = cId;
		this.name = name;
		this.mainBranchLocation = mainBranchLocation;
		this.noOfEmloyees = noOfEmloyees;
		this.noOfProjects = noOfProjects;
	}
}
