package com.world.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import com.world.company.Company;
import com.world.company.cl.CompaniesInfo;

public class Test{
	public static void main(String[] args) 
	{
		
		BeanFactory factory= new XmlBeanFactory(new ClassPathResource("com/common/ac.xml"));
		CompaniesInfo comp = factory.getBean("cInfo", CompaniesInfo.class);
		 System.out.println(comp);

	}
}