package Company;

public class TCS extends ICompany {

	@Override
	public String toString() {
		return "TCS [id=" + id + ", name=" + name + ", Locations=" + Locations + ", noOfEmloyees=" + noOfEmloyees
				+ ", noOfProjects=" + noOfProjects + "]";
	}

	
}
