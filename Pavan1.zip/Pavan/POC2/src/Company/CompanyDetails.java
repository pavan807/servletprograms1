package Company;

import java.util.Map;

public class CompanyDetails {
	Map<Integer, ICompany> comaniesList;

	public Map<Integer, ICompany> getComaniesList() {
		return comaniesList;
	}

	public void setComaniesList(Map<Integer, ICompany> comaniesList) {
		this.comaniesList = comaniesList;
	}
	
	
}
