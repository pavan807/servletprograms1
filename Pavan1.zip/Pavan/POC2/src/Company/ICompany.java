package Company;
import java.util.List;

public abstract class ICompany {
	int id;
	String name;
	List<String> Locations;
	int noOfEmloyees;
	long noOfProjects;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<String> getLocations() {
		return Locations;
	}
	public void setLocations(List<String> locations) {
		Locations = locations;
	}
	public int getNoOfEmloyees() {
		return noOfEmloyees;
	}
	public void setNoOfEmloyees(int noOfEmloyees) {
		this.noOfEmloyees = noOfEmloyees;
	}
	public long getNoOfProjects() {
		return noOfProjects;
	}
	public void setNoOfProjects(long noOfProjects) {
		this.noOfProjects = noOfProjects;
	}
	public ICompany(int id, String name, List<String> locations, int noOfEmloyees, long noOfProjects) {
		super();
		this.id = id;
		this.name = name;
		Locations = locations;
		this.noOfEmloyees = noOfEmloyees;
		this.noOfProjects = noOfProjects;
	}
	
	
}
