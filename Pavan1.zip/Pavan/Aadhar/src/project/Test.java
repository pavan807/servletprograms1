package project;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;


public class Test {

	public static void main(String[] args) 
	{
		BeanFactory factory=new XmlBeanFactory(new ClassPathResource("project/ac.xml"));
		Account ac=(Account)factory.getBean("account", Account.class);
		if(ac.isAadarLinked()==true)
		{
			System.out.println(ac);
		}
		else {
			System.out.println("Aadhar not linked");
		}

}
}