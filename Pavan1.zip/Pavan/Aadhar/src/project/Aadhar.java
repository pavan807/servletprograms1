package project;

public class Aadhar {
	String aadharNo;
	String DOB;
	String fullname;
	Address address;
	
	
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Aadhar [aadharNo=" + aadharNo + ", DOB=" + DOB + ", fullname=" + fullname + ", address=" + address
				+ "]";
	}

	
	
}
