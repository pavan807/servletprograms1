package project;

public class Account {
	String aNo;
	String aHName;
	Aadhar aadharNoisActiveSate;
	boolean aadarLinked;
	Address address;
	public String getaNo() {
		return aNo;
	}
	public void setaNo(String aNo) {
		this.aNo = aNo;
	}
	public String getaHName() {
		return aHName;
	}
	public void setaHName(String aHName) {
		this.aHName = aHName;
	}
	public Aadhar getAadharNoisActiveSate() {
		return aadharNoisActiveSate;
	}
	public void setAadharNoisActiveSate(Aadhar aadharNoisActiveSate) {
		this.aadharNoisActiveSate = aadharNoisActiveSate;
	}
	public boolean isAadarLinked() {
		return aadarLinked;
	}
	public void setAadarLinked(boolean aadarLinked) {
		this.aadarLinked = aadarLinked;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Account [aNo=" + aNo + ", aHName=" + aHName + ", aadharNoisActiveSate=" + aadharNoisActiveSate
				+ ", aadarLinked=" + aadarLinked + ", address=" + address + "]";
	}
	
	
	
	
 
	
}
