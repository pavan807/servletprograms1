package project;

public class Address {
	int DNo;
	String street;
	String aLine1;
	String aLine2;
	int statezip;
	String country;
	
	
	public int getDNo() {
		return DNo;
	}


	public void setDNo(int dNo) {
		DNo = dNo;
	}


	public String getStreet() {
		return street;
	}


	public void setStreet(String street) {
		this.street = street;
	}


	public String getaLine1() {
		return aLine1;
	}


	public void setaLine1(String aLine1) {
		this.aLine1 = aLine1;
	}


	public String getaLine2() {
		return aLine2;
	}


	public void setaLine2(String aLine2) {
		this.aLine2 = aLine2;
	}


	public int getStatezip() {
		return statezip;
	}


	public void setStatezip(int statezip) {
		this.statezip = statezip;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	@Override
	public String toString() {
		return "Address [DNo=" + DNo + ", street=" + street + ", aLine1=" + aLine1 + ", aLine2=" + aLine2
				+ ", statezip=" + statezip + ", country=" + country + "]";
	}
	
	

}
